% Xdot is a vector made up of the 4 equations of motion. Xdot is a first
% order differential that can be solved with ode45.
% t is time specified when function is called, x is a vector made up of the
% initial conditions. - KM
function Xdot = eqs(t, x) 
   
   % r is the stretch of the spring from its resting state.
   % rdot is the velocity in m/s
   % theta is the angle of the spring with respect to the vertical axis
   % thetadot is angular velocity in radians/sec -KM
   
   r = x(1);
   rdot = x(2);
   theta = x(3);
   thetadot = x(4);
   
   % m is mass of the bob, 
   % g is gravity
   % k is the spring constant
   % L is the natural length of the spring in resting position -KM
   
   m = x(5);
   g = x(6);
   k = x(7);
   L = x(8);

   % wr is the springs frequency along its length
   % wtheta is the pendulums frequency of oscillation -KM
   
   wr = sqrt(k/m);
   wtheta = sqrt(g/(L + r));
   
   % Making the vector Xdot with the four equations of motion
   
   Xdot = zeros(length(x), 1);
   Xdot(1) = rdot;
   Xdot(2) = (r + L) * thetadot^2 + g*cos(theta) - wr^2 * r;
   Xdot(3) = thetadot;
   Xdot(4) = (-2/(L + r)) * rdot * thetadot - wtheta^2 * sin(theta);
end
