function anim3d=animation3d(x,y,z,t,L,g,mass,k)

    clf

    %Finding the min & max to set reasonable plot limits
    x_max=max(x);
    y_max=max(y);
    x_min=min(x);
    y_min=min(y);
    z_min=min(z);
    z_max=max(z);
    if z_max>0 %this is checking if it goes above the starting plane, and adjsuting axes accordingly
        limits=[1.1*x_min,1.1*x_max, 1.1*y_min,1.1*y_max, 1.1*z_min, 1.1*z_max];
    else
        limits=[1.1*x_min,1.1*x_max, 1.1*y_min,1.1*y_max, 1.1*z_min, 0.5];
    end
    
    %Making a String with the Parameter information
    Parameters={'Springdulum Parameters:',
    append('g= ',num2str(g),' m/s^2'),
    append('m= ',num2str(mass),' kg'),
    append('k= ',num2str(k),' N/m'),
    append('L= ',num2str(L),' m'),
    };

    anim3d=figure();
    set(gcf,'Visible','on') %this forces it to open a new figure window so the animation works
    axis(limits) %make some reasonable axes
    axis square
    hold on %make it keep animating
    title('Springdulum Animation') %a title
    xlabel('x')
    ylabel('y')
    zlabel('z')
    annotation('textbox',[.85 .7 .2 .2],'String',Parameters,'EdgeColor','none','FontSize',12) %adding some text about the parameters
    spring=plot3([0,x(1)],[0,y(1)],[0,z(1)],'k','LineWidth',1.5); %establish the spring line
    point=plot3(x(1),y(1),z(1),'k.','MarkerSize',75); %establishing where the mass is
    pendulum=animatedline('Color','r','LineStyle','-'); %establish the pendulum trace path
    
    patch([x_min,x_min,x_max,x_max],[y_min,y_max,y_max,y_min],'k')%making the ceiling the pendulum hangs from
    hold off %all this to make the ceiling somewhat transparent
    alpha(0.5)
    hold on
    
    for i=1:length(x)
       %plot(x(i),y(i),z(i),'or') %plot the new mass position
       addpoints(pendulum,x(i),y(i),z(i)) %add the new position to the pendulum trace
       spring.XData = [0,x(i)]; %move the spring line to the right place
       spring.YData = [0,y(i)];
       spring.ZData = [0,z(i)];
       point.XData = x(i); %move the mass to the right place
       point.YData = y(i);
       point.ZData = z(i);
       drawnow %animate it
       pause(0.1)
       %pause(t(i+1)-t(i)) %tthis is the one that does "real time" which
       %makes my computuer upsetti spaghetti
    end
end