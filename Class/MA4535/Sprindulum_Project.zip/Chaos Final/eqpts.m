function [x, y, z] = eqpts(mass, g, k, L)
% Specifying that x y & z are variables    
    syms x y z;
% The equations with velocities and acceleration = 0    
    eqn = [(-k*x*(sqrt(x^2+y^2+z^2)-L))/sqrt(x^2+y^2+z^2) == 0, (-k*y*(sqrt(x^2+y^2+z^2)-L))/sqrt(x^2+y^2+z^2) == 0, ((-k*z*(sqrt(x^2+y^2+z^2)-L))/sqrt(x^2+y^2+z^2)) - mass*g == 0];
% Solving for x, y, z when the above equations = 0   
    [x, y, z] = solve(eqn, [x y z]);
%Converting back to double precision (from symbolic)
    x=double(x);
    y=double(y);
    z=double(z);
end