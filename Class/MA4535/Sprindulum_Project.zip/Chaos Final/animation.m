function anim2d=animation(r,theta,t,L,g,mass,k)

    clf

    %Defining the mass's position in terms of x & y
    x=(L+r).*sin(theta);
    y=-1*(L+r).*cos(theta);

    %Finding the min & max to set reasonable plot limits
    x_max=max(x);
    y_max=max(y);
    x_min=min(x);
    y_min=min(y);
    if y_max>0 %this is checking if it goes above the starting plane, and adjsuting axes accordingly
        limits=[1.1*x_min,1.1*x_max, 1.1*y_min,1.1*y_max];
    else
        limits=[1.1*x_min,1.1*x_max, 1.1*y_min,0.5];
    end
    
    %Making a String with the Parameter information
    Parameters={'Springdulum Parameters:',
    append('g= ',num2str(g),' m/s^2'),
    append('m= ',num2str(mass),' kg'),
    append('k= ',num2str(k),' N/m'),
    append('L= ',num2str(L),' m'),
    };

    anim2d=figure();
    set(gcf,'Visible','on') %this forces it to open a new figure window so the animation works
    axis(limits) %make some reasonable axes
    axis square
    hold on %make it keep animating
    title('Springdulum Animation') %a title
    annotation('textbox',[.85 .7 .2 .2],'String',Parameters,'EdgeColor','none','FontSize',12) %adding some text about the parameters
    rectangle('Position',[x_min,0,x_max-x_min,0.2],'FaceColor',[0 0 0]) %make the "ceiling" the pendulum hangs from
    pendulum=animatedline('Color','r','LineStyle','-'); %establish the pendulum trace path
    spring=plot([0,x(1)],[0,y(1)],'k','LineWidth',1.5); %establish the spring line
    point=plot(x(1),y(1),'k.','MarkerSize',75); %establishing where the mass is
    
    for i=1:(length(t)-1)
       %plot(x(i),y(i),'or') %plot the new mass position
       addpoints(pendulum,x(i),y(i)) %add the new position to the pendulum trace
       spring.XData = [0,x(i)]; %move the spring line to the right place
       spring.YData = [0,y(i)];
       point.XData = x(i); %move the mass to the right place
       point.YData = y(i);
       drawnow %animate it
       pause(0.1)
       %pause(t(i+1)-t(i)) %tthis is the one that does "real time" which
       %makes my computuer upsetti spaghetti
    end
end