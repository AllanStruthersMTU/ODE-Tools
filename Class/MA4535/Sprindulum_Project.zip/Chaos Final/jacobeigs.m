function eigenvals=jacobeigs(m, g, k, L)
%define p
    p = m*g/(k*L);
%defining x,y,z & their velocities as symbolic variables
    syms xdot ydot zdot x y z
%finding the equalibrium points we're interested in
    [x1,x2,x3]=eqpts(m,g,k,L);
%Defining the Jacobian in 3D
    J=jacobian([xdot,ydot,zdot,(1/sqrt(x^2+y^2+z^2)-1)*x,(1/sqrt(x^2+y^2+z^2)-1)*y,(1/sqrt(x^2+y^2+z^2)-1)*z - p],[xdot,ydot,zdot,x,y,z]);
%Subbing the equalibium points into the Jacobian    
    jnew=double(subs(J,[x,y,z],[x1,x2,x3]));
%Finding the eigenvalues of the Jacobian    
    eigenvals=eig(jnew);

end