function Xdot = eqs3d(t,x)
    
    %break apart input vector
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x1dot = x(4);
    x2dot = x(5);
    x3dot = x(6);
    
    %parameters
    m = 10; %kg
    g = 10; %m/s^2
    k = 10; %N/m
    L = .5; %m
    
    %define p
    p = m*g/(k*L);
    
    %calculate derivatives
    Xdot = zeros(length(x),1);
    Xdot(1) = x1dot;
    Xdot(2) = x2dot;
    Xdot(3) = x3dot;
    Xdot(4) = (1/sqrt(x1^2+x2^2+x3^2)-1)*x1;
    Xdot(5) = (1/sqrt(x1^2+x2^2+x3^2)-1)*x2;
    Xdot(6) = (1/sqrt(x1^2+x2^2+x3^2)-1)*x3 - p;
end