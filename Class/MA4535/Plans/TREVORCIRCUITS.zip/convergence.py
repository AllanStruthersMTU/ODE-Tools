"""
FEniCS tutorial demo program: Poisson equation with a combination of
Dirichlet, Neumann, and Robin boundary conditions.

  -div(kappa*grad(u)) = f

This program illustrates a number of different topics:

- How to solve a problem using three different approaches of varying
  complexity: solve / LinearVariationalSolver / assemble + solve
- How to compute fluxes
- How to set combinations of boundary conditions
- How to set parameters for linear solvers
- How to create manufactured solutions with SymPy
- How to create unit tests
- How to represent solutions as structured fields
"""

from __future__ import print_function

from fenics import *
# from boxfield import *
import numpy as np
import matplotlib.pyplot as plt
from ufl import nabla_div
import torch

#---------------------------------------------------------------------
# Solvers
#---------------------------------------------------------------------
"""
def solver(kappa, f, u_D, Nx, Ny,
           degree=1,
           linear_solver='Krylov',
           abs_tol=1E-5,
           rel_tol=1E-3,
           max_iter=1000):
    
    Solve -div(kappa*grad(u) = f on (0, 1) x (0, 1) with 2*Nx*Ny Lagrange
    elements of specified degree and u = u_D on the boundary.
    

    # Create mesh and define function space
    mesh = UnitSquareMesh(Nx, Ny)
    V = FunctionSpace(mesh, 'P', degree)

    # Define boundary condition
    def boundary(x, on_boundary):
        return on_boundary

    bc = DirichletBC(V, u_D, boundary)

    # Define variational problem
    u = TrialFunction(V)
    v = TestFunction(V)
    a = kappa*dot(grad(u), grad(v))*dx
    L = f*v*dx

    # Set linear solver parameters
    prm = LinearVariationalSolver.default_parameters()
    if linear_solver == 'Krylov':
        prm["linear_solver"] = 'gmres'
        prm["preconditioner"] = 'ilu'
        prm["krylov_solver"]["absolute_tolerance"] = abs_tol
        prm["krylov_solver"]["relative_tolerance"] = rel_tol
        prm["krylov_solver"]["maximum_iterations"] = max_iter
    else:
        prm["linear_solver"] = 'lu'

    # Compute solution
    u = Function(V)
    solve(a == L, u, bc, solver_parameters=prm)

    return u
"""



def elasticity(filename,degree):
    # Scaled variables
    mu = 79.3e9
    rho = 8000
    lambda_ = 50e9
    g = 10
    
    # Define boundary condition
    def clamped_boundary(x, on_boundary):
        return on_boundary and (x[0] < 80 or x[0] > 5000)
        
    def lifted_center(x, on_boundary):
        return on_boundary and 2000<x[0]<3000 and x[2]<10
    
     # Define strain and stress
        
    def epsilon(u):
        return 0.5*(nabla_grad(u) + nabla_grad(u).T)
    
    def sigma(u):
        return lambda_*nabla_div(u)*Identity(d) + 2*mu*epsilon(u)
    
    #Define the body forces acting on the bridge
    #The first condition is specifying where the truck is located,
    #The else condition is just the weight of the bridge
    class force(UserExpression):
        def eval(self,value,x):
            if ((x[0]>1000) & (x[0]<2000) & (x[2]>200)):
                value[2] = -3000*g - rho*g
            else:
                value[2] = -rho*g
                
        def value_shape(self):
            return(3,)
    
    # Create mesh and define function space
    mesh = Mesh(filename)
    V = VectorFunctionSpace(mesh, 'P', degree)
      
    bc_1 = DirichletBC(V, Constant((0, 0, 0)), clamped_boundary)
    bc_2 = DirichletBC(V, Constant((0, 0, 0)), lifted_center)
        
    # Define variational problem
    u = TrialFunction(V)
    d = u.geometric_dimension()  # space dimension
    v = TestFunction(V)
            
    f = force(degree=2)
    T = Constant((0, 0, 0))
    a = inner(sigma(u), epsilon(v))*dx
    L = dot(f, v)*dx + dot(T, v)*ds
    
    # Compute solution
    u = Function(V)
    bc = [bc_1,bc_2]
    solve(a == L, u, bc)
    
    # Compute stress
    s = sigma(u) - (1./3)*tr(sigma(u))*Identity(d)  # deviatoric stress
    von_Mises = sqrt(3./2*inner(s, s))
    V = FunctionSpace(mesh, 'P', 1)
    von_Mises = project(von_Mises, V)
    
    return von_Mises
#---------------------------------------------------------------------
# Utility functions
#---------------------------------------------------------------------

def compute_errors(vm_refined, vm):
    """Compute various measures of the error u - u_e, where
    u is a finite element Function and u_e is an Expression."""

    # Get function space
    V = vm.function_space()

    # Explicit computation of L2 norm
    error = np.array(assemble(vm - vm_refined))
    E1 = sqrt(torch.sum(np.square(error)))

    # Explicit interpolation of u_e onto the same space as u
    vm_refined_ = interpolate(vm_refined, V)
    error = np.array(assemble(vm - vm_refined_))
    E2 = sqrt(torch.sum(np.square(error)))

    # Explicit interpolation of u_e to higher-order elements.
    # u will also be interpolated to the space Ve before integration
    Ve = FunctionSpace(V.mesh(), 'P', 5)
    vm_refined_ = interpolate(vm_refined, Ve)
    error = np.array(assemble(vm - vm_refined))
    E3 = sqrt(torch.sum(np.square(error)))

    # Infinity norm based on nodal values
    vm_refined_ = interpolate(vm_refined, V)
    E4 = abs(vm_refined_.vector().get_local() - vm.vector().get_local()).max()

    # L2 norm
    E5 = errornorm(vm_refined, vm, norm_type='L2', degree_rise=3)

    # H1 seminorm
    E6 = errornorm(vm_refined, vm, norm_type='H10', degree_rise=3)

    # Collect error measures in a dictionary with self-explanatory keys
    errors = {'vm - vm_refined': E1,
              'vm - interpolate(vm_refined, V)': E2,
              'interpolate(vm, Ve) - interpolate(vm_refined, Ve)': E3,
              'infinity norm (of dofs)': E4,
              'L2 norm': E5,
              'H10 seminorm': E6}

    return errors

def compute_convergence_rates(max_degree):
    "Compute convergences rates for various error norms"

    h = {}  # discretization parameter: h[degree][level]
    E = {}  # error measure(s): E[degree][level][error_type]

    # Iterate over degrees and mesh refinement levels
    degrees = range(1, max_degree + 1)
    """
    for degree in degrees:
        n = 8  # coarsest mesh division
        h[degree] = []
        E[degree] = []
        for i in range(num_levels):
            h[degree].append(1.0 / n)
            u = solver(kappa, f, u_D, n, n, degree, linear_solver='direct')
            errors = compute_errors(u_e, u)
            E[degree].append(errors)
            print('2 x (%d x %d) P%d mesh, %d unknowns, E1 = %g' %
              (n, n, degree, u.function_space().dim(), errors['u - u_e']))
            n *= 2
    """
            
    files = ['bar400.xml','bar200.xml','bar100.xml','bar25.xml']
    vm_refined = elasticity(files[3],3)
    for degree in degrees:
        h[degree] = []
        E[degree] = []
        for i in range(len(files)-1):
            vm = elasticity(files[i],degree)
            errors = compute_errors(vm_refined,vm)
            E[degree].append(errors)
            print(files[i], 'P%d mesh, %d unkowns, E1 = %g' % (degree,vm.function_space().dim(),errors['vm - vm_refined']))

    # Compute convergence rates
    from math import log as ln  # log is a fenics name too
    etypes = list(E[1][0].keys())
    rates = {}
    for degree in degrees:
        rates[degree] = {}
        for error_type in sorted(etypes):
            rates[degree][error_type] = []
            for i in range(1, num_levels):
                Ei = E[degree][i][error_type]
                Eim1 = E[degree][i - 1][error_type]
                r = ln(Ei / Eim1) / ln(h[degree][i] / h[degree][i - 1])
                rates[degree][error_type].append(round(r, 2))

    return etypes, degrees, rates


#---------------------------------------------------------------------
# Demo programs
#---------------------------------------------------------------------



def convergence_rates():
    "Compute convergence rates in various norms for P1, P2, P3"

    # Compute and print convergence rates
    etypes, degrees, rates = compute_convergence_rates(3)
    for error_type in etypes:
        print('\n' + error_type)
        for degree in degrees:
            print('P%d: %s' % (degree, str(rates[degree][error_type])[1:-1]))


if __name__ == '__main__':

    # run convergence test
    convergence_rates()
